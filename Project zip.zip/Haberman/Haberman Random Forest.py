#!/usr/bin/env python
# coding: utf-8

# In[5]:


# Importing Pandas for Dataframe Manipulation as well as Matplotlib and Seaborn for visualization purposes.
import pandas as pd
from matplotlib import pyplot as plt
import seaborn as sns

# Reading in our Iris Data and printing the first five rows out to the console.
df = pd.read_csv("haberman.csv")
df


# In[26]:


# Importing the 'Train_Test_Split' function fron Scikit-Learn's 'model_selection' package.
from sklearn.model_selection import train_test_split

# Splitting up our dataframe into x and y subsets (x are the independent variables and y is the dependent variable species).
x_data = df.drop("age_young", axis=1)
y_data = df["age_young"]

# Retrieving X and Y train-test sets by calling the 'train_test_split' function. (80-20 Split)
x_train, x_test, y_train, y_test = train_test_split(x_data, y_data, test_size=0.2
                                                   )


# In[27]:


# Importing the RandomForestClassifier Class from Scikit-Learn's 'ensemble' package.
from sklearn.ensemble import RandomForestClassifier

# Creating a new classifier with twenty individual decision trees used to build the random forest.
model = RandomForestClassifier(n_estimators=20)

# Training our model on the X and Y train sets.
model.fit(x_train, y_train)


# In[28]:


# Printing out the accuracy measure for our model.
print("Model Accuracy: " + str(model.score(x_test, y_test)))


# In[ ]:





# In[ ]:




